
// -*- coding: utf-8 -*-
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <algorithm> 

using namespace std;

class Personnage {
    public:
        int vie;
        int defense;
        int degats;
        string arme;
        string nom;
    public:
        Personnage(int v, int def, int deg, string a, string n) : vie(v), defense(def), degats(deg), arme(a), nom(n) {}

        void Attaquer(Personnage* p) {
            int dmg = this->degats - p->defense;
            if (dmg > 0) {
                int initvie=p->vie;
                p->vie -= dmg;
                cout << this->nom << " a "<< this->vie << " vie et attaque " << p->nom << " qui a "<< initvie<< " vie avec " << this->arme << " et inflige " << dmg << " dégâts." << endl;
            }
            else {
                cout << this->nom << " a "<< this->vie << " vie et attaque " << p->nom << " qui a "<< p->vie<< " vie avec " << this->arme << " mais échoue à infliger des dégâts." << endl;
            }
            if (p->vie <= 0) {
          cout << p->nom << " est mort !" << endl;
        } else {
          cout << p->nom << " a donc " << p->vie << " points de vie." << endl;
        }
        }
    };

class Hero : public Personnage {
    public:
        bool pouvoirActif;
        int tourActif;
    public:
        Hero(int v, int def, int deg, string a, string n) : Personnage(v, def, deg, a, n), pouvoirActif(false), tourActif(0) {}

        virtual void lancerPouvoir() = 0;
        
        // destructeur virtuel
        virtual ~Hero() {}
};

class Monstre : public Personnage {
    protected:
        bool estOrc;
        int vieMax;
    public:
        Monstre(int v, int def, int deg, string a, string n, bool orc) : Personnage(v, def, deg, a, n), estOrc(orc), vieMax(v) {
            if (this->estOrc) {
                this->defense += 2;
            }
            else {
                this->defense += 4;
            }
        }

    /*void Attaquer(Hero* h) {
        if (rand() % 2 == 0) { // 50% chance to hit
            Personnage::Attaquer(h);
        }
        else {
            //cout << this->nom << " a "<< this->vie<< " attaque " << h->nom  << " qui a "<< h->vie<< " vie avec " << this->arme << " mais échoue à infliger des dégâts." << endl;
            cout << this->nom << " a "<< this->vie<< " attaque " << h->nom  << " qui a "<< h->vie<< " vie avec " << this->arme << " mais échoue à infliger des dégâts." << endl;
        }
    }*/

    void subirDegats(int dmg) {
        this->vie -= dmg;
        if (this->vie <= 0) {
            cout << this->nom << " a été vaincu !" << endl;
        }
    }
};

class Orc : public Monstre {
    public:
        Orc() : Monstre(rand() % 2 + 10, rand() % 3 + 4, 8, "hache", "Orc", true) {}
};

class Goblin : public Monstre {
    public:
        Goblin() : Monstre(rand() % 2 + 10, rand() % 3 + 2, 5, "gourdin", "Goblin", false) {}
};

class Chevalier : public Hero {
    public:
        Chevalier(string nomPerso) : Hero(rand() % 21 + 50, rand() % 3 + 4, 8, "épée longue", "Chevalier " +  nomPerso) {
            if (rand() % 2 == 0) {
                this->arme = "hallebarde";
                this->degats = 8;
            }
            else {
                this->arme = "épée longue";
                this->degats = 8;
            }}
    void lancerPouvoir() {
        cout << "Le Chevalier utilise son pouvoir spécial : il rajoute 5 de dégâts à son prochain coup !\n";
        this->degats += 5;
        }};

class Clerc : public Hero {
    public:
    Clerc(string nomPerso) : Hero(rand() % 21 + 40, rand() % 3 + 3, 6, "hache", "Clerc "+  nomPerso) {
        if (rand() % 2 == 0) {
            this->arme = "hache";
            this->degats = 6;
        }
        else {
            this->arme = "masse";
            this->degats = 6;
        }
        }
    void lancerPouvoir() {
        this->vie += 5;
        cout << this->nom << " a gagné 5 points de vie grâce à son pouvoir spécial ! il a maintenant " << this->nom <<"\n";
        }
};

class Ninja : public Hero {
  
    public:
        Ninja(string nomPerso) : Hero(rand() % 11 + 30, rand() % 3 + 1, 5, "saï", "Ninja "+  nomPerso) {
        this->arme = "saï";
        this->degats = 5;
        }
    void lancerPouvoir() {
        cout << "Le pouvoir du ninja a été activé : attaque avec l'autre saï" << endl;
        //Attaquer();
    }

};

int main() {
    // Création de l'équipe de héros
    vector<Hero*> equipe;
    string nom;
    cout << "Création de l'équipe de héros :\n";
    for (int i = 1; i <= 4; i++) {
        cout << "Nom du héros " << i << " : ";
        cin >> nom;
        int classe;
        cout << "Choisissez une classe pour " << nom << " :\n";
        cout << "1. Chevalier\n2. Clerc\n3. Ninja\n";
        cin >> classe;
        switch (classe) {
            case 1: equipe.push_back(new Chevalier(nom)); break;
            case 2: equipe.push_back(new Clerc(nom)); break;
            case 3: equipe.push_back(new Ninja(nom)); break;
            default: cout << "Classe invalide.\n"; i--; break;
        }
    }
    // Génération des monstres
    vector<Monstre*> monstres;
    srand(time(NULL));
    for (int i = 0; i < 4; i++) {
        int monstre = rand() % 2;
        if (monstre == 0) {
            monstres.push_back(new Orc());
        }
        else {
            monstres.push_back(new Goblin());
        }
    }

    // Combat
    int tour = 1;
    while (!monstres.empty() && tour < 30) {
        cout << "\n\nTour " << tour << " :\n";
        // Les héros attaquent
        for (Hero* h : equipe) {
            if (monstres.empty()) break;
            cout << "\nC'est au tour de " << h->nom << " d'attaquer !\n";
            if (h->pouvoirActif && h->tourActif > 0) {
                h->tourActif--;
            }
            else {
                h->pouvoirActif = false;
            }
            for (Monstre* m : monstres) {
                if (m->vie > 0) {
                    h->Attaquer(m);
                    if(tour % 3==0){h->lancerPouvoir();};
                    if (m->vie <= 0) {
                        monstres.erase(find(monstres.begin(), monstres.end(), m));
                        delete m;
                    }
                    break;
                }
            }
        }
        if (monstres.empty()) break;
        // Les monstres attaquent
        for (Monstre* m : monstres) {
            if (equipe.empty()) break;
            cout << "\nC'est au tour de " << m->nom << " d'attaquer !\n";
            for (Hero* h : equipe) {
                if (h->vie > 0) {
                    m->Attaquer(h);
                    if (h->vie <= 0) {
                        equipe.erase(find(equipe.begin(), equipe.end(), h));
                        delete h;
                    }
                    break;
                }
            }
        }
        tour++;
    }

    // Résultat
    if (monstres.empty()) {
        cout << "\n\nBravo, l'équipe de héros a vaincu tous les monstres !\n";
    }
    else {
        cout << "\n\nL'équipe de héros a été vaincue par les monstres...\n";
    }

    // Libération de la mémoire
  for (Hero* h : equipe) {
      delete h;
  }
  for (Monstre* e : monstres) {
      delete e;
  }
;

}
